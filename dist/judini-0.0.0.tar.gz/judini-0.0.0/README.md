[metadata]
name = judini
version = 0.0.1
author = Daniel Avila
author_email = daniel@judini.ai
description = Judini's python library
long_description = file: README.md
long_description_content_type = text/markdown
url = https://github.com/JudiniLabs/judini-python.git
project_urls =
    Bug Tracker = https://github.com/pypa/sampleproject/issues
classifiers =
    Programming Language :: Python :: 3
    License :: OSI Approved :: MIT License
    Operating System :: OS Independent

[options]
package_dir =
    = src
packages = find:
python_requires = >=3.6

[options.packages.find]
where = src